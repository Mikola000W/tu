﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pocztowka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
        }

        private void sprawdzCene_Click(object sender, RoutedEventArgs e)
        {
            if(list.IsChecked == true)
            {
                iList.Visibility = Visibility.Visible;
                iPaczka.Visibility = Visibility.Hidden;
                iPocztowka.Visibility = Visibility.Hidden;
                Cena.Text = "Cena: 1,5 zł ";
            } else if (pocztowka.IsChecked == true)
            {
                iPocztowka.Visibility = Visibility.Visible;
                iList.Visibility = Visibility.Hidden;
                iPaczka.Visibility = Visibility.Hidden;
                Cena.Text = "Cena: 1 zł ";

            }
            else if (paczka.IsChecked == true)
            {
                iPaczka.Visibility = Visibility.Visible;
                iList.Visibility = Visibility.Hidden;
                iPocztowka.Visibility = Visibility.Hidden;
                Cena.Text = "Cena: 10 zł ";
            }
        }

        private void zatwierdz_Click(object sender, RoutedEventArgs e)
        {
            if(kodPocztowy.Text.Length == 5)
            {
                int kod;
                bool sukces = int.TryParse(kodPocztowy.Text,out kod);
                if(sukces)
                {
                    MessageBox.Show("Twój kod pocztowy to: "+kod);
                }
                else
                {
                    MessageBox.Show("Twój kod pocztowy zawiera niedozwolone znaki");
                }
            }
            else
            {
                MessageBox.Show("Nieprawidłowa liczba znaków");
            }
        }
    }
}
